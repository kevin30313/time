function mostrarFecha() {
  // Obtener la fecha y hora actual
  const fechaActual = new Date();

  // Obtener el día de la semana, el día, el mes y el año
  const diasSemana = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
  const diaSemana = diasSemana[fechaActual.getDay()];
  const dia = fechaActual.getDate();
  const meses = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];
  const mes = meses[fechaActual.getMonth()];
  const anio = fechaActual.getFullYear();

  // Obtener la hora, los minutos y los segundos
  const hora = fechaActual.getHours();
  const minutos = fechaActual.getMinutes();
  const segundos = fechaActual.getSeconds();

  // Mostrar la fecha y hora actual en un mensaje de alerta
  const mensaje = `Hoy es ${diaSemana} ${dia} de ${mes} de ${anio}, y son las ${hora} horas, ${minutos} minutos con ${segundos} segundos.`;
  alert(mensaje);

  // Calcular el tiempo restante para el final del año
  const finAnio = new Date(anio + 1, 0, 1);
  const tiempoRestante = finAnio - fechaActual;

  // Convertir el tiempo restante a días, horas, minutos y segundos
  const segundosRestantes = Math.floor(tiempoRestante / 1000);
  const minutosRestantes = Math.floor(segundosRestantes / 60);
  const horasRestantes = Math.floor(minutosRestantes / 60);
  const diasRestantes = Math.floor(horasRestantes / 24);

  // Mostrar el tiempo restante en el contenedor con ID "tiemporestante"
  const contenedor = document.getElementById("tiemporestante");
  contenedor.innerHTML = `Faltan ${diasRestantes} días, ${horasRestantes % 24} horas, ${minutosRestantes % 60} minutos y ${segundosRestantes % 60} segundos para que termine el año.`;
}

mostrarFecha();
